function [Cov, Lgth] = PanelAWBootstrapCB(N, T, gamma, h, Chtilde, kappa, rhoe)

Nsim = 1E3; 

% Parameters
htilde = Chtilde*h^(5/9);
siglevel = 0.05;
burnin = 20;
rhoA1 = 0.1;
rhoA2 = 0.1;
rhoalpha = 1;
rhoeps = 0.1;
rhoU1 = 0.3;
rhoU3 = rhoU1;
rhoU2 = 0.1;
B = 999; 

kx = @(x) 0.75.*(1-x.^2).*(abs(x) <= 1);        % Epanechnikov kernel
gx = @(x) -4*x.^3 + 9*x.^2 - 6*x + 2;
beta1x = @(x) 1.5*exp(-10*(x-0.2).^2) + 1.6*exp(-8*(x-0.8).^2);
beta2x = @(x) -0.5*x-0.5*exp(-5*(x-0.8).^2);
trend = (1:T)'/T;

%============================= Monte Carlo ===============================% 
gxtrend = gx(trend);
beta1xtrend = beta1x(trend);
beta2xtrend = beta2x(trend);
mBeta = [gx(trend) beta1x(trend) beta2x(trend)];

% Volatility Process
smoothvol = @(x,k) 1 + k*x;
flucvol = @(x) 1 + 0.5*cos(2*pi*4*x);
smoothflucvol = @(x) 1 + x + 0.5*cos(2*pi*4*x);

mSigmaE = generateVolatilityE(N, T, kappa, smoothvol, flucvol, smoothflucvol, trend);
mSigmaEps = CrossSectionalCov(rhoeps,N);
mSigmaU1 = CrossSectionalCov(rhoU1,N);
mSigmaU2 = CrossSectionalCov(rhoU2,N);
mSigmaU3 = rhoU3*eye(N);
mSigmaU = [mSigmaU1 mSigmaU3; mSigmaU3 mSigmaU2];


AMSE = zeros(Nsim,3);
gCov = zeros(Nsim,4);   % Pointwise | Gsub | Gunion | Full Sample
gLgth = zeros(Nsim,4);  % Pointwise | Gsub | Gunion | Full Sample
beta1Cov = zeros(Nsim,4);  % Pointwise | Gsub | Gunion | Full Sample
beta2Cov = zeros(Nsim,4);   % Pointwise | Gsub | Gunion | Full Sample
beta1Lgth = zeros(Nsim,4); % Pointwise | Gsub | Gunion | Full Sample
beta2Lgth = zeros(Nsim,4); % Pointwise | Gsub | Gunion | Full Sample

tic
parfor simiter = 1:Nsim
    
    % Report progress
    if (mod(simiter,1E2)) == 0
        fprintf('Iteration %5d out of %5d \n',simiter,Nsim);
    end
    
    % DGP
    mE = zeros(T+burnin,N);
    mX1 = zeros(T+burnin,N);             % first regressor
    mX2 = zeros(T+burnin,N);             % second regressor
    for timeid = 2:T+burnin
        mE(timeid,:) = rhoe*mE(timeid-1,:) + mvnrnd(zeros(1,N),mSigmaEps);
        vU = mvnrnd(zeros(1,2*N),mSigmaU)
        mX1(timeid,:) = rhoA1*mX1(timeid-1,:) + vU(1:N);
        mX2(timeid,:) = rhoA2*mX2(timeid-1,:) + vU(N+1:end);
%         mX1(timeid,:) = rhoA1*mX1(timeid-1,:) + mvnrnd(zeros(1,N),mSigmaU);
%         mX2(timeid,:) = rhoA2*mX2(timeid-1,:) + mvnrnd(zeros(1,N),mSigmaU);
    end
    mE = mE(end-T+1:end,:);
    
    mFixedEffectX = unifrnd(-1,1,[2,N]);    
    mX1 = mFixedEffectX(1,:) + sin(trend) + mX1(end-T+1:end,:);
    mX2 = mFixedEffectX(2,:) + (trend-1/2).^2 + mX2(end-T+1:end,:);
    mX = cat(3,ones(T,N),mX1,mX2);             % one layer for each regressor
    valpha = rhoalpha*mean(mX1(:,1:N-1),1) + normrnd(0,1,[1,N-1]);
    valpha = [valpha -sum(valpha)]';     

    mY = zeros(T,N);
    mTranMat = [0.3 0.7; 0.1 0.9];
    % mTranMat = [0.8 0.2; 0.45 0.55];
    MissingMarkovChain = dtmc(mTranMat);
    mMissing = zeros(T,N);
    mY(:,1) = valpha(1) + sum(squeeze(mX(:,1,:)).*mBeta,2) + mSigmaE(:,1).*mE(:,1);
    mMissing(1,:) = binornd(1,7/8,N,1);           % generate initial missing values

    for i = 1:N
        mY(:,i) = valpha(i) + sum(squeeze(mX(:,i,:)).*mBeta,2) + mSigmaE(:,i).*mE(:,i);
        mMissing(:,i) = simulate(MissingMarkovChain,T-1,"X0",(1-mMissing(1,i))*[1,0]+mMissing(1,i)*[0,1])-1;           % generate missing values
    end
    mY(logical(1-mMissing)) = nan;            % missing values in y_{it}

    % The adapted LLDV estimation and Confidence Intervals
    [mbetaHat,betaPWInt,betaSTIntFullSpan,betaSTIntGset] = AWBootstrap(B,mY,mX,h,htilde,kx,siglevel,gamma);
    
    if sum(isnan(mbetaHat(:)))> 0
        continue
    end

    vghath = mbetaHat(:,1);
    mbeta1hath = mbetaHat(:,2);
    mbeta2hath = mbetaHat(:,3);

    % Average MSE
    AMSE(simiter,:) = [mean((vghath - gxtrend).^2) mean((mbeta1hath - beta1xtrend).^2) mean((mbeta2hath - beta2xtrend).^2)];   % MSE

    %== Coverage and length ==%
    
    % Pointwise
    gPWInt = betaPWInt(:,:,1);
    gPWCov = mean((gxtrend <= gPWInt(:,2)).*(gxtrend >= gPWInt(:,1)));
    gPWLgth = median(gPWInt(:,2) - gPWInt(:,1));
    
    beta1PWInt = betaPWInt(:,:,2);
    beta1PWCov = mean((beta1xtrend <= beta1PWInt(:,2)).*(beta1xtrend >= beta1PWInt(:,1)));
    beta1PWLgth = median(beta1PWInt(:,2) - beta1PWInt(:,1));

    beta2PWInt = betaPWInt(:,:,3);
    beta2PWCov = mean((beta2xtrend <= beta2PWInt(:,2)).*(beta2xtrend >= beta2PWInt(:,1)));
    beta2PWLgth = median(beta2PWInt(:,2) - beta2PWInt(:,1));
    
    % Simultaneous
    AllGsetsh = generateUniformSet(h,T);
    gSTCov = zeros(1,length(AllGsetsh));
    gSTLgth = zeros(1,length(AllGsetsh));
    beta1STCov = zeros(1,length(AllGsetsh));
    beta1STLgth = zeros(1,length(AllGsetsh));
    beta2STCov = zeros(1,length(AllGsetsh));
    beta2STLgth = zeros(1,length(AllGsetsh));

    for Gid = 1:length(AllGsetsh)
        
        Gseti = AllGsetsh{Gid};
        
        % Global trend
        gxtrendG = gx(Gseti); 
        gSTInt = betaSTIntGset{1,Gid};
        gSTCov0 = mean((gxtrendG <= gSTInt(:,2)).*(gxtrendG >= gSTInt(:,1)));
        gSTCov(Gid) = 1-(gSTCov0<1);   
        
        gST_FullSpan = betaSTIntFullSpan{1,Gid}
        gSTLgth(Gid) = median(gST_FullSpan(:,2) - gST_FullSpan(:,1));
        
        % First slope coefficient
        beta1xtrendG = beta1x(Gseti);
        beta1STInt = betaSTIntGset{2,Gid};
        beta1STCov0 = mean((beta1xtrendG <= beta1STInt(:,2)).*(beta1xtrendG >= beta1STInt(:,1)));
        beta1STCov(Gid) = 1-(beta1STCov0<1); 
        
        beta1ST_FullSpan = betaSTIntFullSpan{2,Gid}
        beta1STLgth(Gid) = median(beta1ST_FullSpan(:,2) - beta1ST_FullSpan(:,1)); 

        % Second slope coefficient
        beta2xtrendG = beta2x(Gseti);
        beta2STInt = betaSTIntGset{3,Gid};
        beta2STCov0 = mean((beta2xtrendG <= beta2STInt(:,2)).*(beta2xtrendG >= beta2STInt(:,1)));
        beta2STCov(Gid) = 1-(beta2STCov0<1);  
        
        beta2ST_FullSpan = betaSTIntFullSpan{3,Gid}
        beta2STLgth(Gid) = median(beta2ST_FullSpan(:,2) - beta2ST_FullSpan(:,1)); 
    
    end
    gCov(simiter,:) = [gPWCov gSTCov];
    gLgth(simiter,:) = [gPWLgth gSTLgth];
    beta1Cov(simiter,:) = [beta1PWCov beta1STCov];
    beta1Lgth(simiter,:) = [beta1PWLgth beta1STLgth];
    beta2Cov(simiter,:) = [beta2PWCov beta2STCov];
    beta2Lgth(simiter,:) = [beta2PWLgth beta2STLgth];
            
end
toc

% Summarize results
Cov = [mean(gCov,1);mean(beta1Cov,1);mean(beta2Cov,1)];
Lgth = [mean(gLgth,1);mean(beta1Lgth,1);mean(beta2Lgth,1);median(gLgth,1);median(beta1Lgth,1);median(beta2Lgth,1)];

% Save results
dlmwrite(strcat('Cov_N_',num2str(N),'_T_',num2str(T),'_h_',num2str(h),'_C_',num2str(Chtilde),'_gamma_',num2str(gamma),'_k_',num2str(kappa),'_re_',num2str(rhoe),'.txt'),Cov,'precision',10); 
dlmwrite(strcat('Lgth_N_',num2str(N),'_T_',num2str(T),'_h_',num2str(h),'_C_',num2str(Chtilde),'_gamma_',num2str(gamma),'_k_',num2str(kappa),'_re_',num2str(rhoe),'.txt'),Lgth,'precision',10); 
dlmwrite(strcat('CovGlobalTrendAllMC_N_',num2str(N),'_T_',num2str(T),'_h_',num2str(h),'_C_',num2str(Chtilde),'_gamma_',num2str(gamma),'_k_',num2str(kappa),'_re_',num2str(rhoe),'.txt'),gCov,'precision',10); 
dlmwrite(strcat('LgthGlobalTrendAllMC_N_',num2str(N),'_T_',num2str(T),'_h_',num2str(h),'_C_',num2str(Chtilde),'_gamma_',num2str(gamma),'_k_',num2str(kappa),'_re_',num2str(rhoe),'.txt'),gLgth,'precision',10); 
dlmwrite(strcat('CovBeta_1_AllMC_N_',num2str(N),'_T_',num2str(T),'_h_',num2str(h),'_C_',num2str(Chtilde),'_gamma_',num2str(gamma),'_k_',num2str(kappa),'_re_',num2str(rhoe),'.txt'),beta1Cov,'precision',10);
dlmwrite(strcat('LgthBeta_1_AllMC_N_',num2str(N),'_T_',num2str(T),'_h_',num2str(h),'_C_',num2str(Chtilde),'_gamma_',num2str(gamma),'_k_',num2str(kappa),'_re_',num2str(rhoe),'.txt'),beta1Lgth,'precision',10); 
dlmwrite(strcat('CovBeta_2_AllMC_N_',num2str(N),'_T_',num2str(T),'_h_',num2str(h),'_C_',num2str(Chtilde),'_gamma_',num2str(gamma),'_k_',num2str(kappa),'_re_',num2str(rhoe),'.txt'),beta2Cov,'precision',10);
dlmwrite(strcat('LgthBeta_2_AllMC_N_',num2str(N),'_T_',num2str(T),'_h_',num2str(h),'_C_',num2str(Chtilde),'_gamma_',num2str(gamma),'_k_',num2str(kappa),'_re_',num2str(rhoe),'.txt'),beta2Lgth,'precision',10); 

dlmwrite(strcat('Avg_AMSE_N_',num2str(N),'_T_',num2str(T),'_h_',num2str(h),'_C_',num2str(Chtilde),'_gamma_',num2str(gamma),'_k_',num2str(kappa),'_re_',num2str(rhoe),'.txt'),mean(AMSE,1),'precision',10); 
dlmwrite(strcat('Std_AMSE_N_',num2str(N),'_T_',num2str(T),'_h_',num2str(h),'_C_',num2str(Chtilde),'_gamma_',num2str(gamma),'_k_',num2str(kappa),'_re_',num2str(rhoe),'.txt'),std(AMSE,1),'precision',10); 
end


function mS = CrossSectionalCov(rho,N)

mS = zeros(N,N);
for i=1:N
    for j=1:N
        d = abs(j-i);
        mS(i,j) = rho^d;
    end
end

end


function mSigmaE = generateVolatilityE(N, T, kappa, smoothvol, flucvol, smoothflucvol, trend)

if kappa==0
    mSigmaE = ones(T,N);
else
    mSigmaE = zeros(T,N);
    mChoice = randi([1,6], 1, N);
    
    for i=1:N
        if mChoice(i)==1    %homoskedasticity
            mSigmaE(:,i) = smoothvol(trend,0);
        elseif mChoice(i)==2
            mSigmaE(:,i) = smoothvol(trend,kappa);  % smoothly increasing
        elseif mChoice(i)==3
            mSigmaE(:,i) = smoothvol(trend,-1*kappa);  % smoothly decreasing
        elseif mChoice(i)==4
            mSigmaE(:,i) = flucvol(trend);  % smoothly fluctuating
        elseif mChoice(i)==5
            mSigmaE(:,i) = smoothflucvol(trend);  % smoothly increasing and fluctuating
        end
    end
end
end


%########## Unions of G Subsets ##########%
function AllGsets = generateUniformSet(h,n)
 
   Uh = zeros(4,ceil(200*h)+1);
   for j = 1:4       
       Uh(j,:) = (j/5)-h+(0:ceil(200*h))/100;      
   end
   Gsub = unique([Uh(1,:) Uh(4,:)]');
   Gsub = Gsub((Gsub<=1)&(Gsub>=1/n));
   Guni = unique(Uh(:));
   Guni = Guni((Guni<=1)&(Guni>=1/n));   
   Gall = (1:n)'/n;
   AllGsets = {Gsub,Guni,Gall};  
 
end


%########## Local Linear Dummy Variable Estimation ##########%
function [mBetaHat,valphaHat] = local_linear_dummy(mY,mX,h,kx,varargin)

warning('off','all')

defaultGsetOption = upper('FullSample');
expectedGsetOption = {upper('AllGSubset'),upper('AllGset'),upper('FullSample'),upper('Subsample'),upper('FullUnion')};
defaultSmoothOption = upper('Regular');
expectedSmoothOption = {upper('Regular'),upper('Oversmooth')};
OptionalInputs = inputParser;
addParameter(OptionalInputs,'GsetOption',defaultGsetOption,@(x) any(validatestring(upper(x),expectedGsetOption))); 
addParameter(OptionalInputs,'SmoothOption',defaultSmoothOption,@(x) any(validatestring(upper(x),expectedSmoothOption))); 
addOptional(OptionalInputs,'OversmoothBW',h,@(x) isnumeric(x) && isscalar(x) && (x > 0)); 
parse(OptionalInputs,varargin{:});
GsetOption = upper(OptionalInputs.Results.GsetOption);
SmoothOption = upper(OptionalInputs.Results.SmoothOption);

switch SmoothOption
    case upper('Regular')
        htilde = h;
    case upper('Oversmooth')
        htilde = OptionalInputs.Results.OversmoothBW;
end

[T,N] = size(mY);
Npara = size(mX,3);             % number of parameter curves
mMissing = 1-ismissing(mY);     % matrix of indicators of missing values
mY(isnan(mY))=0;                % each column becomes \vy_{i}^{M}

AllGsets = generateUniformSet(h,T);
Gsub = AllGsets{1};
Guni = AllGsets{2};
Gall = AllGsets{3};

switch GsetOption
    case upper('FullSample')
        Gset = Gall;
        selectFun = 1;
    case upper('AllGSubset')
        Gset = {Gsub,Guni};
        selectFun = 2;
    case upper('AllGset')
        Gset = AllGsets;
        selectFun = 2;
    case upper('Subsample')
        Gset = Gsub;
        selectFun = 1;
    case upper('FullUnion')
        Gset = Guni;
        selectFun = 1;
end

trend = (1:T)'./T;
if selectFun == 1
    GsetNum = length(Gset); 
    mBetaHat = zeros(Npara,GsetNum);
    mAlphaHat = zeros(N,GsetNum);
    for j = 1:GsetNum
        tau = Gset(j);  
        
        vKernel = kx((trend-tau)/htilde);
        vomegaTau = sum(vKernel.*mMissing,1).^(-1);    % the element is \nu_{\tai,i}
        vomegaTau(isinf(vomegaTau)) = 0;
        omegaTau = sum(vomegaTau);

        vyBar = sum(vomegaTau.*mY,2)/omegaTau;
        mYDemean = mY - vyBar;                         % for Step 2
        mZBarTau = zeros(T,2*Npara);
        for id = 1:N
            mZi = squeeze(mX(:,id,:));
            mZBarTau = mZBarTau + vomegaTau(id)*(mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
        end
        mZBarTau = mZBarTau/omegaTau;

        % partialling valpha out
        mK0 = sqrt(vKernel)*vKernel';
        mZZTilde = zeros(2*Npara,2*Npara);
        vZyTilde = zeros(2*Npara,1);
        for id = 1:N
            mZi = squeeze(mX(:,id,:));
            mZiTau = (mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
            mProjid = vomegaTau(id)*mMissing(:,id).*mK0;

            % Step 1
            mZiTilde = sqrt(vKernel).*mZiTau - mProjid*(mZiTau-mZBarTau);
            mZZTilde = mZZTilde + mZiTilde'*mZiTilde;

            % Step 2
            vyiTilde = sqrt(vKernel).*mY(:,id) - mProjid*mYDemean(:,id);
            vZyTilde = vZyTilde + mZiTilde'*vyiTilde;
        end
        vThetaHatTau = mZZTilde\vZyTilde;
        mBetaHat(:,j) = vThetaHatTau(1:Npara);

        % Fixed effect estimates over time
        valphaHatTau = zeros(N,1);
        for id = 1:N
            mZi = squeeze(mX(:,id,:));
            mZiTau = (mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
            veiHatTau = mYDemean(:,id) - (mZiTau-mZBarTau)*vThetaHatTau;
            valphaHatTau(id) = vomegaTau(id)*vKernel'*veiHatTau;
        end
        mAlphaHat(:,j) = valphaHatTau;
            
    end
    mBetaHat = mBetaHat';
    valphaHat = mean(mAlphaHat,2);
else
    mBetaHat = cell(1,length(Gset));
    valphaHat = cell(1,length(Gset));
    
    for Gid = 1:length(Gset)
        
        Gseti = Gset{Gid};
        GsetNum = length(Gseti); 
        mbetaStar = zeros(Npara,GsetNum);
        mAlphaHat = zeros(N,GsetNum);
        for j = 1:GsetNum
            tau = Gseti(j);  
            
            vKernel = kx((trend-tau)/htilde);
            vomegaTau = sum(vKernel.*mMissing,1).^(-1);    % the element is \nu_{\tai,i}
            vomegaTau(isinf(vomegaTau)) = 0;
            omegaTau = sum(vomegaTau);

            vyBar = sum(vomegaTau.*mY,2)/omegaTau;
            mYDemean = mY - vyBar;                         % for Step 2
            mZBarTau = zeros(T,2*Npara);
            for id = 1:N
                mZi = squeeze(mX(:,id,:));
                mZBarTau = mZBarTau + vomegaTau(id)*(mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
            end
            mZBarTau = mZBarTau/omegaTau;

            % partialling valpha out
            mK0 = sqrt(vKernel)*vKernel';
            mZZTilde = zeros(2*Npara,2*Npara);
            vZyTilde = zeros(2*Npara,1);
            for id = 1:N
                mZi = squeeze(mX(:,id,:));
                mZiTau = (mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
                mProjid = vomegaTau(id)*mMissing(:,id).*mK0;

                % Step 1
                mZiTilde = sqrt(vKernel).*mZiTau - mProjid*(mZiTau-mZBarTau);
                mZZTilde = mZZTilde + mZiTilde'*mZiTilde;

                % Step 2
                vyiTilde = sqrt(vKernel).*mY(:,id) - mProjid*mYDemean(:,id);
                vZyTilde = vZyTilde + mZiTilde'*vyiTilde;
            end
            vThetaHatTau = mZZTilde\vZyTilde;
            mbetaStar(:,j) = vThetaHatTau(1:Npara);

            % Fixed effect estimates over time
            valphaHatTau = zeros(N,1);
            for id = 1:N
                mZi = squeeze(mX(:,id,:));
                mZiTau = (mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
                veiHatTau = mYDemean(:,id) - (mZiTau-mZBarTau)*vThetaHatTau;
                valphaHatTau(id) = vomegaTau(id)*vKernel'*veiHatTau;
            end
            mAlphaHat(:,j) = valphaHatTau;
        
        end
        mBetaHat{Gid} = mbetaStar';
        valphaHat{Gid} = mean(mAlphaHat,2);

    end
  
end

end


%########## Autoregressive Wild Bootstrap ##########%
function [mbetaHat,betaPWInt,betaSTIntFullSpan,betaSTIntGset] = AWBootstrap(B,mY,mX,h,htilde,kx,siglevel,gamma)

[T,N,dReg] = size(mX);

%== Parameter specifications ==%
AllGsets = generateUniformSet(h,T);

%== Preliminary estimation for constructing intervals ==%
mBetaHatAllGset = local_linear_dummy(mY,mX,h,kx,'GsetOption','AllGset');
mbetaHat = mBetaHatAllGset{3};

%== Dynamics of residuals ==%

% Estimation under oversmoothing
[mbetatildeAllGset, valphatildeAllGset] = local_linear_dummy(mY,mX,h,kx,'GsetOption','AllGset',...
    'SmoothOption','Oversmooth','OversmoothBW',htilde);
mbetatilde = mbetatildeAllGset{3};        % T x N
valphatilde = valphatildeAllGset{3};      % N-dimensional

% Calculate residuals: Missing pattern automatically kept
mResi = zeros(T,N);
mYTilde = zeros(T,N);
for i = 1:N
    mYTilde(:,i) = valphatilde(i) + sum(squeeze(mX(:,i,:)).*mbetatilde,2);
    mResi(:,i) = mY(:,i) - mYTilde(:,i); 
end

%== Bootstrap ==%
GsetSize = cellfun(@length,AllGsets,'UniformOutput',false);
GsetSizeBoot = num2cell([GsetSize{:};[B;dReg]*ones(1,length(AllGsets))]',2);
mbetaHatAWBootG = cellfun(@zeros,GsetSizeBoot,'UniformOutput',false);
for Biter = 1:B
    
    % Generate bootstrap samples
    vNuBoot = normrnd(0,sqrt(1-gamma^2),[T,1]);
    vXiBoot = zeros(T,1); vXiBoot(1) = normrnd(0,1);
    for id = 2:T
        vXiBoot(id) = gamma*vXiBoot(id-1) + vNuBoot(id);        
    end
    mResiBoot = mResi.*vXiBoot;
    mYBoot = mYTilde + mResiBoot;     % missing pattern automatically kept
    
    % Estimation
    mbetastarBootAllGset = local_linear_dummy(mYBoot,mX,h,kx,'GsetOption','AllGset');

    for Gid = 1:length(mbetastarBootAllGset)
        for regid = 1:dReg
            mbetaHatAWBootG{Gid}(:,Biter,regid) = mbetastarBootAllGset{Gid}(:,regid); 
        end
    end
end


%========= Pointwise Intervals =========%
betaPWInt = zeros(T,2,dReg);
for regid = 1:dReg
    mbetaHatAWBootid = mbetaHatAWBootG{3}(:,:,regid);
    
    % Critical values
    betaPWcrival = quantile(mbetaHatAWBootid-mbetatilde(:,regid),[siglevel/2 1-siglevel/2],2);
    
    % Intervals
    betaPWInt(:,:,regid) = [mbetaHat(:,regid) - betaPWcrival(:,2) mbetaHat(:,regid) - betaPWcrival(:,1)];    
end

%========= Simultaneous Intervals =========%
alphaPmax = siglevel;
alphaPmin = 1/B;
TheoCov = 1-siglevel;

betaSTIntFullSpan = cell(dReg,length(AllGsets));   % over full time-span t = 1,2,...,T, for easy plots
betaSTIntGset = cell(dReg,length(AllGsets));       % over G, for easy evaluation of size and length
for Gid = 1:length(AllGsets)
    for regid = 1:dReg
        
        % Estimation under oversmoothing
        mbetatildeGiRegid = mbetatildeAllGset{Gid}(:,regid);
        
        % Bootstrap estimates
        mbetaHatAWBootSTGiRegid = mbetaHatAWBootG{Gid}(:,:,regid);
        
        % Differences
        betaDiffAWBootGiRegid = mbetaHatAWBootSTGiRegid-mbetatildeGiRegid;
        
        %=====================================================================================%
        betaAWBootST_GiRegidMin = quantile(betaDiffAWBootGiRegid,[alphaPmin/2 1-alphaPmin/2],2); 
        
        % Simultaneous coverage (sum over columns, covering for all tau counts as a success)
        betaAWBMinCov = mean((betaDiffAWBootGiRegid <= betaAWBootST_GiRegidMin(:,2)).* (betaDiffAWBootGiRegid >= betaAWBootST_GiRegidMin(:,1)),1);
        betaAWBMinCov = 1- mean(betaAWBMinCov<1);
        if betaAWBMinCov >= 1-siglevel
            betaCov1 = betaAWBMinCov;
            alphaS = alphaPmin + 1/B;
            while alphaS <= alphaPmax 
                betaQuanalphaS = quantile(betaDiffAWBootGiRegid,[alphaS/2 1-alphaS/2],2);
                betaCov2 = mean((betaDiffAWBootGiRegid <= betaQuanalphaS(:,2)).* (betaDiffAWBootGiRegid >= betaQuanalphaS(:,1)),1);
                betaCov2 = 1- mean(betaCov2<1);
                if abs(betaCov2 - TheoCov) <= abs(betaCov1 - TheoCov)
                    alphaS = alphaS + 1/B;
                    betaCov1 = betaCov2;
                else
                    break
                end
            end
            alphaS = alphaS - 1/B;
        else
            alphaS = alphaPmin;
        end
       
        % over full time span t = 1,...,T
        betaAWB_FullSpan = quantile(mbetaHatAWBootG{3}(:,:,regid)-mbetatilde(:,regid),[alphaS/2 1-alphaS/2],2);
        betaSTIntFullSpan{regid,Gid} = [mbetaHat(:,regid) - betaAWB_FullSpan(:,2) mbetaHat(:,regid) - betaAWB_FullSpan(:,1)];
        
        % over G only
        betaAWB_G = quantile(betaDiffAWBootGiRegid,[alphaS/2 1-alphaS/2],2);
        betaSTIntGset{regid,Gid} = [mBetaHatAllGset{Gid}(:,regid) - betaAWB_G(:,2) mBetaHatAllGset{Gid}(:,regid) - betaAWB_G(:,1)]; 
        
    end
end

end
