# -*- coding: utf-8 -*-
"""
Created on Wed Nov  8 12:12:49 2023

@author: 86078bvs
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

d_months = {'January':'01', 'February':'02', 'March':'03', 'April':'04', 'May':'05', 'June':'06', 'July':'07','August':'08','September':'09','October':'10','November':'11','December':'12'}

# preprocess PM2.5 data
df_pm = pd.read_csv('GlobalPM25-V5GL04-Monthly-199801-202212-wThresFrac.csv', delimiter=';')
df_pop = df_pm.iloc[:,[0,1,6]]
df_pm = df_pm.iloc[:,:3]

# preprocess population
df_pop = df_pop.rename(columns={'Year and Month':'Date'})
df_pop.Date = df_pop.Date.astype('Int64')
df_pop = df_pop[df_pop.Date.between(199901,202112)]
df_pop.Date = pd.to_datetime(df_pop.Date, format='%Y%m')
df_pop = df_pop.set_index('Date')
df_pop = df_pop.rename(columns={'Total Population [million people]':'Pop'})

idx = pd.date_range('01-01-1999', '12-01-2021', freq='MS')
df_popi = pd.DataFrame()
for country in df_pop['Region'].unique():
    s = df_pop[df_pop['Region']==country]
    s = s.Pop
    s.index = pd.DatetimeIndex(s.index)
    s = s.str.replace(',','.')
    s = pd.to_numeric(s)
    df_popi[country] = s

df_popi = df_popi
    
df_pm = df_pm.rename(columns={'Year and Month':'Date'})
df_pm.Date = df_pm.Date.astype('Int64')
df_pm = df_pm[df_pm.Date.between(199901,202112)]
df_pm.Date = pd.to_datetime(df_pm.Date, format='%Y%m')
df_pm = df_pm.set_index('Date')
df_pm = df_pm.rename(columns={'Population-Weighted PM2.5 [ug/m3]':'PM25'})

idx = pd.date_range('01-01-1999', '12-01-2021', freq='MS')
df_p = pd.DataFrame()
for country in df_pm['Region'].unique():
    s = df_pm[df_pm['Region']==country]
    s = s.PM25
    s.index = pd.DatetimeIndex(s.index)
    df_p[country] = s


# preprocess Total Death Cases data
df_dc = pd.read_csv('UNdata_Export_20231113_160745770.csv')
df_dc = df_dc.iloc[:,[0,1,3,7]]
df_dc.Month = df_dc.Month.map(d_months)
df_dc = df_dc.dropna()
df_dc.Year = df_dc.Year.astype(str)
df_dc['Date'] = df_dc.Year + df_dc.Month
df_dc = df_dc.drop(['Year','Month'], axis=1)
df_dc.Date = pd.to_datetime(df_dc.Date, format='%Y%m')
df_dc = df_dc.set_index('Date')
df_dc = df_dc.rename(columns={'Country or Area':'Region'})


df_d = pd.DataFrame()
for country in df_dc['Region'].unique():
    s = df_dc[df_dc['Region']==country]
    s = s.Value
    s.index = pd.DatetimeIndex(s.index)
    s = s[~s.index.duplicated()]
    s = s.reindex(idx, fill_value=np.nan)  
    df_d[country] = s

df_d = df_d.rename(columns={'Brunei Darussalam':'Brunei','Cabo Verde':'Cape Verde','China, Hong Kong SAR':'Hong Kong','China, Macao SAR':'Macao','Czechia':'Czech Republic','Falkland Islands (Malvinas)':'Falkland Islands','Iran (Islamic Republic of)':'Iran','North Macedonia':'Macedonia','Republic of Korea':'South Korea','Republic of Moldova':'Moldova','Russian Federation':'Russia','Saint Barthélemy':'Saint-Barthélemy','Saint Helena ex. dep.':'Saint Helena','Saint-Martin (French part)':'Saint-Martin','Syrian Arab Republic':'Syria','Türkiye':'Turkey','United Kingdom of Great Britain and Northern Ireland':'United Kingdom','United States of America':'United States','Venezuela (Bolivarian Republic of)':'Venezuela','Wallis and Futuna Islands':'Wallis and Futuna','Åland Islands':'Aland'})
df_d = df_d.drop('United States Virgin Islands',axis=1)
df_d = df_d[sorted(df_d.columns)]

df_popi = df_popi[df_d.columns]
df_p = df_p[df_d.columns]

df_d = df_d.divide(df_popi)
df_p = df_p[sorted(df_p.columns)]

# get subset of data
# indic = np.random.choice(np.arange(0,len(df_d.columns),1), 50, replace=False)
# df_d = df_d.iloc[:,indic]
# df_p = df_p.iloc[:,indic]

df_d = df_d.iloc[216:,:]
df_p = df_p.iloc[216:,:]


# Data plots
print('Average percentage of missings over time',np.mean(df_d.isnull().mean(axis=1)))
plt.plot(df_d.isnull().mean(axis=1))
plt.show()

mX = df_p.values
mY = df_d.values

plt.plot(mX)
plt.show()

plt.plot(mY)
plt.show()

plt.plot(np.mean(mX, axis=1))
plt.plot(np.quantile(mX, 0.1, axis=1), c='r')
plt.plot(np.quantile(mX, 0.9, axis=1), c='g')
plt.title('X')
plt.show()

plt.plot(np.nanmean(mY, axis=1))
plt.plot(np.nanquantile(mY, 0.05, axis=1), c='r')
plt.plot(np.nanquantile(mY, 0.95, axis=1), c='g')
plt.title('Y')
plt.show()



'''
df_p.to_csv('PM25_data.csv')
df_d.to_csv('Mortality_data.csv')
'''