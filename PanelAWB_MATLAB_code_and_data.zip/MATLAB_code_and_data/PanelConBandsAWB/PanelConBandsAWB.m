% clear; clcdisp

% Initialize
kx = @(x) 0.75.*(1-x.^2).*(abs(x) <= 1);        % Epanechnikov kernel

B = 9999;
Chtilde = 2;
siglevel = 0.05;
gamma = 0.2;
gridh = 0.06:0.015:0.27;
sSit = 'Full';

mY = '__insertYdata__';
vUnitNames ='__insertnames__' ;
vDates = '__insertDates__';
vDataVars = {'__insertVariableNames__'};
mXData = '__insertXdata__';
mX = cat(3,ones(T,N),mXData);

[T,N] = size(mY);

% Bandwidth selection
[dH1_opt, h] = OptBW_ModCV(mY, mX, N, T, kx, gridh);
htilde = Chtilde*h^(5/9);
htilde_low = Chtilde*dH1_opt^(5/9);

% The adapted LLDV estimation
tic
[mBetaHat,valphaHat] = local_linear_dummy(mY,mX,h,kx);
toc

% Plot estimated alpha's
fAlpha = figure('visible','off');
plot(valphaHat,'LineWidth',2)
set(gca,'XTick',[1:N])
set(gca,'xticklabel',vUnitNames)
grid on
xtickangle(90)
ax = gca;
ax.FontSize = 20;
title(['Alpha ',sSit],'FontSize',45,'Interpreter','latex')
set(fAlpha,'Position',[0,0,1000,800])
filename = char(strcat(sSit,'_Alpha_Hat_'));
saveas(fAlpha,filename,'png')

% Get estimated Y and residuals
mResi = zeros(T,N);
mY_hat = zeros(T,N);
for i = 1:N
    mY_hat(:,i) = valphaHat(i) + sum(squeeze(mX(:,i,:)).*mBetaHat,2);
    mResi(:,i) = mY(:,i) - mY_hat(:,i);
end

TestResiduals(mResi, vDates, vUnitNames);

% Confidence bands
tic
[mbetaHat,betaPWInt,betaSTIntFullSpan,betaSTIntGset] = AWBootstrap(B,mY,mX,h,htilde,kx,siglevel,gamma);
toc

% Plot Results
MakeGraphs(mbetaHat, betaPWInt, betaSTIntFullSpan, vDates, vDataVars, sSit); % Coefficients
PlotFit(mY,mY_hat,vDates,vUnitNames, sSit, false); % Fit
PlotTrendData(mY, mbetaHat, betaPWInt, betaSTIntFullSpan, vDates, vUnitNames, sSit) % Estimated Global Trend in Data

function [] = TestResiduals(mRes, vDates, vUnitNames)
    vResAvg = mean(mRes,2,'omitmissing');

    % Average serial correlation
    h1 = figure('Visible','off');
    t = plot(vDates,vResAvg);
    grid on
    xtickangle(45)
    datetick('x','yyyy','keeplimits')
    ax = gca;
    ax.FontSize = 20;
    title('Residuals','FontSize',45,'Interpreter','latex')
    set(h1,'Position',[0,0,1000,800])
    %lg = legend(p,vUnitNames,'Interpreter','latex','Location','southeastoutside','FontSize',15);
    %set(lg,'color','none','Box','off')
    filename = char(strcat('Average_Residuals'));
    saveas(h1,filename,'png')

    vResAvg = mean(mRes,2,'omitmissing');
    h2 = figure('Visible','off');
    autocorr(vResAvg);
    ax = gca;
    ax.FontSize = 20;
    title('Sample ACF Residuals','FontSize',45,'Interpreter','latex')
    set(h2,'Position',[0,0,1000,800])
    filename = char(strcat('Autocorr_Average_Residuals'));
    saveas(h2,filename,'png')

    % Plot data in mRes stacked along axis=1 in single plot
    h = figure('Visible','off');
    p = plot(vDates,mRes,'o');
    grid on
    xtickangle(45)
    datetick('x','yyyy','keeplimits')
    ax = gca;
    ax.FontSize = 20;
    title('Residuals','FontSize',45,'Interpreter','latex')
    set(h,'Position',[0,0,1000,800])
    %lg = legend(p,vUnitNames,'Interpreter','latex','Location','southeastoutside','FontSize',15);
    %set(lg,'color','none','Box','off')
    filename = char(strcat('Regression_Residuals'));
    saveas(h,filename,'png')
end

function [dH1_opt, dH2_opt] = OptBW_ModCV(mY, mX, N, T, kx, gridh)
iH = length(gridh);
iShort = iH - 4;

lList = [0 2 4 6];
NlList = length(lList);

mLosses = zeros(T, NlList, iH);

for j=1:iH
    h = gridh(j);
    mLosses(:,:,j) = ModCVLoss_OptLocal(mY,mX,kx,lList,h, N, T, NlList);
end

mListOptLocal_short = zeros(T,NlList);
mListOptLocal_full = zeros(T,NlList);
for lid = 1:NlList
    for j = 1:T
        [~, optloc1] = min(squeeze(mLosses(j,lid,1:iShort)));
        [~, optloc2] = min(squeeze(mLosses(j,lid,1:end)));
        mListOptLocal_short(j,lid) = gridh(optloc1);
        mListOptLocal_full(j,lid) = gridh(optloc2);
    end
end
dH1_opt = mean(mean(mListOptLocal_short, 1));
dH2_opt = mean(mean(mListOptLocal_full, 1));
end


function mLoss_ModCV_OptLocal = ModCVLoss_OptLocal(mY,mX,kx,lList,h, N, T, NlList)
[~,~,Npara] = size(mX);
trend = (1:T)'./T;

wx = @(x) normpdf(trend,x, sqrt(0.025));          % other variance: 0.0125
mResi2 = zeros(T,NlList); 
% Step 1: alpha using full sample
[~,valphaHat_step1] = local_linear_dummy(mY,mX,h,kx);

mMissing = 1-ismissing(mY);
mY(isnan(mY))=0;
% Step 2: leave out
for j = 1:T 
    vMissing = mMissing(j,:);

    tau = j/T;
    vKernel = kx((trend-tau)/h);
    vomegaTau = sum(vKernel.*mMissing,1).^(-1);    % the element is \nu_{\tai,i}
    vomegaTau(isinf(vomegaTau)) = 0;
    omegaTau = sum(vomegaTau);

    for lid = 1:NlList       
        l = lList(lid);
        id_leavelout = j-l:j+l;
        id_leavelout = id_leavelout(id_leavelout>=1 & id_leavelout<=T);

        vyBar = sum(vomegaTau.*mY,2)/omegaTau;
        mYDemean = mY - vyBar;                         % for Step 2
        mZBarTau = zeros(T,2*Npara);
        for id = 1:N
            mZi = squeeze(mX(:,id,:));
            mZBarTau = mZBarTau + vomegaTau(id)*(mMissing(:,id).*[mZi mZi.*(trend-tau)/h]);
        end
        mZBarTau = mZBarTau/omegaTau;
    
        % partialling valpha out
        mK0 = sqrt(vKernel)*vKernel';
        mZZTilde = zeros(2*Npara,2*Npara);
        vZyTilde = zeros(2*Npara,1);
        for id = 1:N
            mZi = squeeze(mX(:,id,:));
            mZiTau = (mMissing(:,id).*[mZi mZi.*(trend-tau)/h]);
            mProjid = vomegaTau(id)*mMissing(:,id).*mK0;
            
            % Step 1
            mZiTilde = sqrt(vKernel).*mZiTau - mProjid*(mZiTau-mZBarTau);
            mZiTilde_leavelout = mZiTilde;
            mZiTilde_leavelout(id_leavelout,:) = [];
            mZZTilde = mZZTilde + mZiTilde_leavelout'*mZiTilde_leavelout;
            
            % Step 2
            vyiTilde = sqrt(vKernel).*mY(:,id) - mProjid*mYDemean(:,id);
            vyiTilde_leavelout = vyiTilde;
            vyiTilde_leavelout(id_leavelout,:) = [];
            vZyTilde = vZyTilde + mZiTilde_leavelout'*vyiTilde_leavelout;
        end

        vThetaHatTau_leavelout = mZZTilde\vZyTilde;
        vBetaHat_leavelout = vThetaHatTau_leavelout(1:Npara);

        % Step 3
        mResi2(j,lid) = SSR_ModCV(mY(j,:), squeeze(mX(j,:,:)),vBetaHat_leavelout, valphaHat_step1, vMissing,N);
    end         
end

mLoss_ModCV_OptLocal = zeros(T,NlList); 
for j = 1:T
    tau = j/T;
    vwtau = wx(tau);
    mLoss_ModCV_OptLocal(j,:) = sum(mResi2.*vwtau,1)/T;
end

end

function [dSSR] = SSR_ModCV(vY, mX, vBetaHat, valphahat, vMissing,N)
    vY = vY(:);
    vMissing = vMissing(:);
    vY_hat = valphahat + mX*vBetaHat;
    dSSR = sum((vMissing.*(vY - vY_hat)).^2)/N;
end


function [] = PlotTrendData(mY, mbetaHat, betaPWInt, betaSTIntFullSpan, vDates, vUnitNames, sSit)
    vghat = mbetaHat(:,1);
    gSTbands = betaSTIntFullSpan{1,3};
    %gPWbands = betaPWInt(:,:,1);

    figure('visible','off');
    subplot(1,2,1);
    plot(vDates,mY,'o');
    hold on
    plot(vDates,vghat,'-k','LineWidth',4)
    hold on 
%     plot(vDates,gPWbands,'--r','LineWidth',2);
%     hold on
    plot(vDates,gSTbands,'-b','LineWidth',2);
    grid on
    xtickangle(45)
%     xtickformat("yyy-MM-dd")
%     xtimelabels = xticklabels;
    datetick('x','yyyy','keeplimits')
    ax = gca;
%     ax.XTick = sort([ax.XTick vDates(Minldx)]);
%     ax.XTickLabel = sort([xtimelabels; MinDate]);
%     xticklabels(sort([xtimelabels; MinDate])');
%     xtickformat("yy-MM-dd")
    ax.FontSize = 18; 

%     lg = legend(dat],vUnitNames,'Interpreter','latex','Location','southeastoutside','FontSize',15);
%     xticklabels(sort([xtimelabels; MinDate])');
%     xtickformat("yy-MM-dd")
%     lg = legend([vUnitNames,'$\hat{g}$'],'Interpreter','latex','Location','eastoutside','FontSize',15);
%     set(lg,'color','none','Box','off') 
    title('Data','FontSize',30)
    
    subplot(1,2,2);
    plot(vDates,vghat,'-k','LineWidth',2)
    hold on
    plot(vDates,gSTbands,'-.b','LineWidth',2)
    grid on
    xtickangle(45)
%     xtickformat("yyyy-MM-dd")
    datetick('x','yyyy','keeplimits')
    ax = gca;
%     ax.XTick = sort([ax.XTick dataset_dates(MinIdx)]);
%     ax.XTickLabel = sort([xtimelabels; MinDate]);
%     xticklabels(sort([xtimelabels; MinDate])');
%     xtickformat("yy-MM-dd")
    ax.FontSize = 18; 
    lg = legend({'$\hat{g}$','ST'},'Interpreter','latex','Location','SE','FontSize',25);
    set(lg,'color','none') 
    title(['Global trend'],'FontSize',30)
    set(lg,'color','none','Box','off') 
    set(gcf,'Position',[0,0,1600,800])
    filename = char(strcat('globaltrend_bandsFS_',sSit));
    saveas(gcf,filename,'png')

end

function [ha hb hc] = shadedplots(x, y1, y2, varargin)


% plot the shaded area
y = [y1; (y2-y1)]'; 
ha = area(x, y);
set(ha(1), 'FaceColor', 'none') % this makes the bottom area invisible
set(ha, 'LineStyle', 'none')

% plot the line edges
% hold on 
% hb = plot(x, y1, 'LineWidth', 1);
% hc = plot(x, y2, 'LineWidth', 1);
% hold off

% set the line and area colors if they are specified
switch length(varargin)
    case 0
    case 1
        set(ha(2), 'FaceColor', varargin{1})
    case 2
        set(ha(2), 'FaceColor', varargin{1})
        % set(hb, 'Color', varargin{2})
        % set(hc, 'Color', varargin{2})
    otherwise
end

% put the grid on top of the colored area
set(gca, 'Layer', 'top')
grid on

end

function [] = MakeGraphs(mbetaHat, betaPWInt, betaSTIntFullSpan, vDates, vDataVars, sSit)
    % Plot estimated coefficients and PW, ST confidence intervals   
    Nreg = size(mbetaHat,2);
    grayColor = [.7 .7 .7];
    for k = 1:Nreg
        sName = vDataVars{k};
        fFullSample = figure('visible','off'); 
        % hPW2 = plot(vDates,betaPWInt(:,:,k),'--r','LineWidth',2);
        % hold on
        hST = plot(vDates,betaSTIntFullSpan{k,3},'--k','LineWidth',2);
        hold on
        hPW = shadedplots(vDates, betaPWInt(:,1,k)', betaPWInt(:,2,k)',grayColor,'k');
        hold on
        plot(vDates,mbetaHat(:,k),'-k','LineWidth',2)
        hold off
        grid on
        xtickangle(45)
        datetick('x','yyyy','keeplimits')
        ax = gca;
        ax.FontSize = 20;
        % lg = legend([hPW2(1),hST(1)],{'PW','ST'},'Interpreter','latex','Location','NE','FontSize',25);
        % set(lg,'color','none','Box','off')
        title(sName,'FontSize',35,'Interpreter','latex')
        set(fFullSample,'Position',[0,0,1000,800])
        filename = char(strcat(sSit,'_FullSample_',vDataVars{k}));
        saveas(fFullSample,filename,'png')
    end

end

function [] = PlotFit(mY,mY_hat,vDates,vUnitNames, sSit, bBoost)
    % Plot Country-Specific Fit
    [~,N] = size(mY);
    for i=1:N
        vY = mY(:,i);
        vY_hat = mY_hat(:,i);
        fCountry = figure('visible','off');
        hY = plot(vDates,vY,'o');
        hold on
        hYhat = plot(vDates,vY_hat,'LineWidth',2);
        hold off
        grid on
        xtickangle(45)
        datetick('x','yyyy','keeplimits')
        ax = gca;
        ax.FontSize = 18;
        lg = legend([hY(1),hYhat(1)],{'$y_{it}$','$\hat{y}_{it}$'},'Interpreter','latex','Location','SE','FontSize',25);
        set(lg,'color','none','Box','off')
        title(['Fit ',vUnitNames{i}],'FontSize',30,'Interpreter','latex')
        set(fCountry,'Position',[0,0,1000,800])
        if bBoost
            filename = char(strcat(sSit,'_Boosted_','Fit_',vUnitNames{i}));
        else
            filename = char(strcat(sSit,'_','Fit_',vUnitNames{i}));
        end
        saveas(fCountry,filename,'png')
    end
end

function [] = PlotStacked(mData,vDates,vUnitNames, sName, sSit)
sName1 = sName;
% Plot data in mData stacked along axis=1 in single plot
h = figure('Visible','off');
p = plot(vDates,mData,'o');
grid on
xtickangle(45)
datetick('x','yyyy','keeplimits')
ax = gca;
ax.FontSize = 20;
title(['Data ',sName1],'FontSize',45,'Interpreter','latex')
set(h,'Position',[0,0,1000,800])
lg = legend(p,vUnitNames,'Interpreter','latex','Location','southeastoutside','FontSize',15);
set(lg,'color','none','Box','off')
filename = char(strcat(sSit,'_Data_',sName));
saveas(h,filename,'png')

% Plot average in mData over time
vAvg = mean(mData, 2,"omitmissing");
h2 = figure('Visible','off');
p2 = plot(vDates, vAvg,'LineWidth',2);
grid on
xtickangle(45)
datetick('x','yyyy','keeplimits')
ax2 = gca;
ax2.FontSize = 20;
title(['Average ',sName1],'FontSize',45,'Interpreter','latex')
set(h2,'Position',[0,0,1000,800])
filename = char(strcat(sSit,'_Avg_',sName));
saveas(h2,filename,'png')
end

%########## Local Linear Dummy Variable Estimation ##########%
function [mBetaHat,valphaHat] = local_linear_dummy(mY,mX,h,kx,varargin)

warning('off','all')

defaultGsetOption = upper('FullSample');
expectedGsetOption = {upper('AllGSubset'),upper('AllGset'),upper('FullSample'),upper('Subsample'),upper('FullUnion')};
defaultSmoothOption = upper('Regular');
expectedSmoothOption = {upper('Regular'),upper('Oversmooth')};
OptionalInputs = inputParser;
addParameter(OptionalInputs,'GsetOption',defaultGsetOption,@(x) any(validatestring(upper(x),expectedGsetOption))); 
addParameter(OptionalInputs,'SmoothOption',defaultSmoothOption,@(x) any(validatestring(upper(x),expectedSmoothOption))); 
addOptional(OptionalInputs,'OversmoothBW',h,@(x) isnumeric(x) && isscalar(x) && (x > 0)); 
parse(OptionalInputs,varargin{:});
GsetOption = upper(OptionalInputs.Results.GsetOption);
SmoothOption = upper(OptionalInputs.Results.SmoothOption);

switch SmoothOption
    case upper('Regular')
        htilde = h;
    case upper('Oversmooth')
        htilde = OptionalInputs.Results.OversmoothBW;
end

[T,N] = size(mY);
Npara = size(mX,3);             % number of parameter curves
mMissing = 1-ismissing(mY);     % matrix of indicators of missing values
mY(isnan(mY))=0;                % each column becomes \vy_{i}^{M}

AllGsets = generateUniformSet(h,T);
Gsub = AllGsets{1};
Guni = AllGsets{2};
Gall = AllGsets{3};

switch GsetOption
    case upper('FullSample')
        Gset = Gall;
        selectFun = 1;
    case upper('AllGSubset')
        Gset = {Gsub,Guni};
        selectFun = 2;
    case upper('AllGset')
        Gset = AllGsets;
        selectFun = 2;
    case upper('Subsample')
        Gset = Gsub;
        selectFun = 1;
    case upper('FullUnion')
        Gset = Guni;
        selectFun = 1;
end

trend = (1:T)'./T;
if selectFun == 1
    GsetNum = length(Gset); 
    mBetaHat = zeros(Npara,GsetNum);
    mAlphaHat = zeros(N,GsetNum);
    for j = 1:GsetNum
        tau = Gset(j);  
        
        vKernel = kx((trend-tau)/htilde);
        vomegaTau = sum(vKernel.*mMissing,1).^(-1);    % the element is \nu_{\tai,i}
        vomegaTau(isinf(vomegaTau)) = 0;
        omegaTau = sum(vomegaTau);

        vyBar = sum(vomegaTau.*mY,2)/omegaTau;
        mYDemean = mY - vyBar;                         % for Step 2
        mZBarTau = zeros(T,2*Npara);
        for id = 1:N
            mZi = squeeze(mX(:,id,:));
            mZBarTau = mZBarTau + vomegaTau(id)*(mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
        end
        mZBarTau = mZBarTau/omegaTau;

        % partialling valpha out
        mK0 = sqrt(vKernel)*vKernel';
        mZZTilde = zeros(2*Npara,2*Npara);
        vZyTilde = zeros(2*Npara,1);
        for id = 1:N
            mZi = squeeze(mX(:,id,:));
            mZiTau = (mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
            mProjid = vomegaTau(id)*mMissing(:,id).*mK0;

            % Step 1
            mZiTilde = sqrt(vKernel).*mZiTau - mProjid*(mZiTau-mZBarTau);
            mZZTilde = mZZTilde + mZiTilde'*mZiTilde;

            % Step 2
            vyiTilde = sqrt(vKernel).*mY(:,id) - mProjid*mYDemean(:,id);
            vZyTilde = vZyTilde + mZiTilde'*vyiTilde;
        end
        vThetaHatTau = mZZTilde\vZyTilde;
        mBetaHat(:,j) = vThetaHatTau(1:Npara);

        % Fixed effect estimates over time
        valphaHatTau = zeros(N,1);
        for id = 1:N
            mZi = squeeze(mX(:,id,:));
            mZiTau = (mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
            veiHatTau = mYDemean(:,id) - (mZiTau-mZBarTau)*vThetaHatTau;
            valphaHatTau(id) = vomegaTau(id)*vKernel'*veiHatTau;
        end
        mAlphaHat(:,j) = valphaHatTau;
            
    end
    mBetaHat = mBetaHat';
    valphaHat = mean(mAlphaHat,2);
else
    mBetaHat = cell(1,length(Gset));
    valphaHat = cell(1,length(Gset));
    
    for Gid = 1:length(Gset)
        
        Gseti = Gset{Gid};
        GsetNum = length(Gseti); 
        mbetaStar = zeros(Npara,GsetNum);
        mAlphaHat = zeros(N,GsetNum);
        for j = 1:GsetNum
            tau = Gseti(j);  
            
            vKernel = kx((trend-tau)/htilde);
            vomegaTau = sum(vKernel.*mMissing,1).^(-1);    % the element is \nu_{\tai,i}
            vomegaTau(isinf(vomegaTau)) = 0;
            omegaTau = sum(vomegaTau);

            vyBar = sum(vomegaTau.*mY,2)/omegaTau;
            mYDemean = mY - vyBar;                         % for Step 2
            mZBarTau = zeros(T,2*Npara);
            for id = 1:N
                mZi = squeeze(mX(:,id,:));
                mZBarTau = mZBarTau + vomegaTau(id)*(mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
            end
            mZBarTau = mZBarTau/omegaTau;

            % partialling valpha out
            mK0 = sqrt(vKernel)*vKernel';
            mZZTilde = zeros(2*Npara,2*Npara);
            vZyTilde = zeros(2*Npara,1);
            for id = 1:N
                mZi = squeeze(mX(:,id,:));
                mZiTau = (mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
                mProjid = vomegaTau(id)*mMissing(:,id).*mK0;

                % Step 1
                mZiTilde = sqrt(vKernel).*mZiTau - mProjid*(mZiTau-mZBarTau);
                mZZTilde = mZZTilde + mZiTilde'*mZiTilde;

                % Step 2
                vyiTilde = sqrt(vKernel).*mY(:,id) - mProjid*mYDemean(:,id);
                vZyTilde = vZyTilde + mZiTilde'*vyiTilde;
            end
            vThetaHatTau = mZZTilde\vZyTilde;
            mbetaStar(:,j) = vThetaHatTau(1:Npara);

            % Fixed effect estimates over time
            valphaHatTau = zeros(N,1);
            for id = 1:N
                mZi = squeeze(mX(:,id,:));
                mZiTau = (mMissing(:,id).*[mZi mZi.*(trend-tau)/htilde]);
                veiHatTau = mYDemean(:,id) - (mZiTau-mZBarTau)*vThetaHatTau;
                valphaHatTau(id) = vomegaTau(id)*vKernel'*veiHatTau;
            end
            mAlphaHat(:,j) = valphaHatTau;
        
        end
        mBetaHat{Gid} = mbetaStar';
        valphaHat{Gid} = mean(mAlphaHat,2);

    end
  
end

end

%########## Unions of G Subsets ##########%
function AllGsets = generateUniformSet(h,n)
 
   Uh = zeros(4,ceil(200*h)+1);
   for j = 1:4       
       Uh(j,:) = (j/5)-h+(0:ceil(200*h))/100;      
   end
   Gsub = unique([Uh(1,:) Uh(4,:)]');
   Gsub = Gsub((Gsub<=1)&(Gsub>=1/n));
   Guni = unique(Uh(:));
   Guni = Guni((Guni<=1)&(Guni>=1/n));   
   Gall = (1:n)'/n;
   AllGsets = {Gsub,Guni,Gall};  
 
end


%########## Autoregressive Wild Bootstrap ##########%
function [mbetaHat,betaPWInt,betaSTIntFullSpan,betaSTIntGset] = AWBootstrap(B,mY,mX,h,htilde,kx,siglevel,gamma)

[T,N,dReg] = size(mX);

%== Parameter specifications ==%
AllGsets = generateUniformSet(h,T);

%== Preliminary estimation for constructing intervals ==%
mBetaHatAllGset = local_linear_dummy(mY,mX,h,kx,'GsetOption','AllGset');
mbetaHat = mBetaHatAllGset{3};

%== Dynamics of residuals ==%

% Estimation under oversmoothing
[mbetatildeAllGset, valphatildeAllGset] = local_linear_dummy(mY,mX,h,kx,'GsetOption','AllGset',...
    'SmoothOption','Oversmooth','OversmoothBW',htilde);
mbetatilde = mbetatildeAllGset{3};        % T x N
valphatilde = valphatildeAllGset{3};      % N-dimensional

% Calculate residuals: Missing pattern automatically kept
mResi = zeros(T,N);
mYTilde = zeros(T,N);
for i = 1:N
    mYTilde(:,i) = valphatilde(i) + sum(squeeze(mX(:,i,:)).*mbetatilde,2);
    mResi(:,i) = mY(:,i) - mYTilde(:,i); 
end

%== Bootstrap ==%
GsetSize = cellfun(@length,AllGsets,'UniformOutput',false);
GsetSizeBoot = num2cell([GsetSize{:};[B;dReg]*ones(1,length(AllGsets))]',2);
mbetaHatAWBootG = cellfun(@zeros,GsetSizeBoot,'UniformOutput',false);
for Biter = 1:B
    
    % Generate bootstrap samples
    vNuBoot = normrnd(0,sqrt(1-gamma^2),[T,1]);
    vXiBoot = zeros(T,1); vXiBoot(1) = normrnd(0,1);
    for id = 2:T
        vXiBoot(id) = gamma*vXiBoot(id-1)+ vNuBoot(id);        
    end
    mResiBoot = mResi.*vXiBoot;
    mYBoot = mYTilde + mResiBoot;     % missing pattern automatically kept
    
    % Estimation
    mbetastarBootAllGset = local_linear_dummy(mYBoot,mX,h,kx,'GsetOption','AllGset');

    for Gid = 1:length(mbetastarBootAllGset)
        for regid = 1:dReg
            mbetaHatAWBootG{Gid}(:,Biter,regid) = mbetastarBootAllGset{Gid}(:,regid); 
        end
    end
end


%========= Pointwise Intervals =========%
betaPWInt = zeros(T,2,dReg);
for regid = 1:dReg
    mbetaHatAWBootid = mbetaHatAWBootG{3}(:,:,regid);
    
    % Critical values
    betaPWcrival = quantile(mbetaHatAWBootid-mbetatilde(:,regid),[siglevel/2 1-siglevel/2],2);
    
    % Intervals
    betaPWInt(:,:,regid) = [mbetaHat(:,regid) - betaPWcrival(:,2) mbetaHat(:,regid) - betaPWcrival(:,1)];    
end

%========= Simultaneous Intervals =========%
alphaPmax = siglevel;
alphaPmin = 1/B;
TheoCov = 1-siglevel;

betaSTIntFullSpan = cell(dReg,length(AllGsets));   % over full time-span t = 1,2,...,T, for easy plots
betaSTIntGset = cell(dReg,length(AllGsets));       % over G, for easy evaluation of size and length
for Gid = 1:length(AllGsets)
    for regid = 1:dReg
        
        % Estimation under oversmoothing
        mbetatildeGiRegid = mbetatildeAllGset{Gid}(:,regid);
        
        % Bootstrap estimates
        mbetaHatAWBootSTGiRegid = mbetaHatAWBootG{Gid}(:,:,regid);
        
        % Differences
        betaDiffAWBootGiRegid = mbetaHatAWBootSTGiRegid-mbetatildeGiRegid;
        
        %=====================================================================================%
        betaAWBootST_GiRegidMin = quantile(betaDiffAWBootGiRegid,[alphaPmin/2 1-alphaPmin/2],2); 
        
        % Simultaneous coverage (sum over columns, covering for all tau counts as a success)
        betaAWBMinCov = mean((betaDiffAWBootGiRegid <= betaAWBootST_GiRegidMin(:,2)).* (betaDiffAWBootGiRegid >= betaAWBootST_GiRegidMin(:,1)),1);
        betaAWBMinCov = 1- mean(betaAWBMinCov<1);
        if betaAWBMinCov >= 1-siglevel
            betaCov1 = betaAWBMinCov;
            alphaS = alphaPmin + 1/B;
            while alphaS <= alphaPmax 
                betaQuanalphaS = quantile(betaDiffAWBootGiRegid,[alphaS/2 1-alphaS/2],2);
                betaCov2 = mean((betaDiffAWBootGiRegid <= betaQuanalphaS(:,2)).* (betaDiffAWBootGiRegid >= betaQuanalphaS(:,1)),1);
                betaCov2 = 1- mean(betaCov2<1);
                if abs(betaCov2 - TheoCov) <= abs(betaCov1 - TheoCov)
                    alphaS = alphaS + 1/B;
                    betaCov1 = betaCov2;
                else
                    break
                end
            end
            alphaS = alphaS - 1/B;
        else
            alphaS = alphaPmin;
        end
       
        % over full time span t = 1,...,T
        betaAWB_FullSpan = quantile(mbetaHatAWBootG{3}(:,:,regid)-mbetatilde(:,regid),[alphaS/2 1-alphaS/2],2);
        betaSTIntFullSpan{regid,Gid} = [mbetaHat(:,regid) - betaAWB_FullSpan(:,2) mbetaHat(:,regid) - betaAWB_FullSpan(:,1)];
        
        % over G only
        betaAWB_G = quantile(betaDiffAWBootGiRegid,[alphaS/2 1-alphaS/2],2);
        betaSTIntGset{regid,Gid} = [mBetaHatAllGset{Gid}(:,regid) - betaAWB_G(:,2) mBetaHatAllGset{Gid}(:,regid) - betaAWB_G(:,1)]; 
        
    end
end

end