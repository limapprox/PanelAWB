This is the ReadMe file for the codes to replicate the output in the paper 

'Bootstrapping trending time-varying coefficient panel models with missing observations.'

Authors: Yicong Lin, Bernhard van der Sluis, Marina Friedrich

The code package contains the following folders:

- Mortality_PM25: contains the code and data to replicate the empirical illustration regarding the effect of surface PM 2.5 emissions on mortality.
	- raw mortality data: UNdata_Export_20231113_160745770.csv
	- raw PM 2.5 data: GlobalPM25-V5GL04-Monthly-199801-202212-wThresFrac.csv
	- code for preprocessing: preprocessingMortality_PM25.py
	- mortality data: Mortality_data.csv
	- Pm 2.5 data: PM25_data.csv
	- replication code: PanelConBandsAWB_Mortality.m

The PM2.5 dataset is available	at https://sites.wustl.edu/acag/datasets/. Kindly reach out to Aaron van Donkelaar (aaron.vandonkelaar@wustl.edu) for further permissions if you wish to use the data.  

- PanelConBandsAWB: contains the code for future application of the methods proposed in the paper.
	- code: PanelConBandsAWB.m 

- Simulations: contains the code to replicate the Monte Carlo study in the paper.
	- code for fixed bandwidth-simulations (gamma=0.2): PanelAWBootstrapCB.m
	- code for optimal bandwidth-simulations (gamma=0.2): in folder OptimalBW
	- code for optimal bandwidth-simulations (different gammas): SimBW_PLMCV_gamma.m